# Net Tay Xanh V2 — gói font dùng trực tiếp trong LaTeX

Gói này được thiết kế để chia sẻ cùng dự án LaTeX. Người nhận **không cần cài font vào Windows/macOS/Linux**. File TTF được nạp trực tiếp từ thư mục `fonts/`.

## Cấu trúc

```text
NetTayXanh_LaTeX_Package_v0.2/
├── fonts/
│   └── NetTayXanhV2-Regular.ttf
├── nettayxanh.sty
├── demo.tex
├── demo.pdf
├── OFL.txt
└── README.md
```

## Chạy thử

Giải nén gói, mở terminal tại đúng thư mục rồi dùng một trong các lệnh:

```powershell
xelatex demo.tex
```

```powershell
lualatex demo.tex
```

```powershell
tectonic demo.tex
```

Không dùng `pdflatex`, vì font được nạp qua `fontspec`.

## Dùng trong tài liệu khác

Sao chép `nettayxanh.sty` và cả thư mục `fonts/` vào thư mục chính của dự án. Trong phần đầu tài liệu:

```tex
\usepackage{nettayxanh}
```

Dùng cho một đoạn:

```tex
{\NetTayXanh This text uses the handwriting font.}
```

Hoặc dùng lệnh ngắn:

```tex
Normal text, then \textnett{handwritten text 123 ABC}.
```

Đặt làm font chính của tài liệu:

```tex
\AtBeginDocument{\NetTayXanh}
```

Font mặc định bật OpenType contextual alternates (`calt`) để các ký tự lặp có thể đổi biến thể. Để so sánh khi tắt alternates:

```tex
{\NetTayXanhPlain aaaaa banana cabana}
```

## Dùng trên Overleaf

1. Tạo dự án mới và upload toàn bộ nội dung của gói, giữ nguyên thư mục `fonts/`.
2. Trong phần cài đặt dự án, chọn compiler **XeLaTeX** hoặc **LuaLaTeX**.
3. Chọn `demo.tex` hoặc tài liệu chính của bạn rồi compile.

## Nếu đổi vị trí thư mục font

Khai báo đường dẫn mới trước `\usepackage{nettayxanh}`:

```tex
\newcommand{\NetTayXanhFontPath}{assets/fonts/}
\usepackage{nettayxanh}
```

## Phạm vi ký tự hiện tại

- `a-z`
- `A-Z`
- `0-9`
- dấu cách
- contextual alternates cho các glyph có biến thể

Các ký tự tiếng Việt có dấu và phần lớn dấu câu chưa nằm trong bản font hiện tại. LaTeX sẽ dùng font khác hoặc hiển thị ký tự thiếu nếu chúng xuất hiện trong vùng đang áp dụng `\NetTayXanh`.

## Chia sẻ và giấy phép

Khi chia sẻ công khai, hãy gửi **toàn bộ file ZIP**, bao gồm `OFL.txt`. Điều khoản đầy đủ trong `OFL.txt` là văn bản áp dụng cho font; tài liệu PDF tạo bằng font không cần đóng gói kèm font trừ khi người nhận cần biên dịch lại nguồn LaTeX.

Phiên bản gói: 0.2 — 2026-10-15.
